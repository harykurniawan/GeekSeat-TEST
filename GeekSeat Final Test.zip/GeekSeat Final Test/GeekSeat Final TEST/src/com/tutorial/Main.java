package com.tutorial;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int a = 0, b = 1, c;
        int d = 0, e = 1, f;
        int nA, nB;
        int personAaod, personAyod;
        int personBaod, personByod;
        int totalA, totalB;
        float Z;
        float JumlahA, JumlahB, rerata;

        System.out.println("\n\t GEEKSEAT TEST \n\n");

        System.out.print(" Person A : \n");
        System.out.print(" Age Of Death : \n");
        personAaod = input.nextInt();
        System.out.print(" Year Of Death : \n");
        personAyod = input.nextInt();

        System.out.print(" Person B : \n");
        System.out.print(" Age Of Death : \n");
        personBaod = input.nextInt();
        System.out.print(" Year of Death : \n");
        personByod = input.nextInt();

        JumlahA = personAyod - personAaod;

        if (JumlahA > 0) {
            System.out.println("\n A People Killed on Year " + " : " + JumlahA);
        } else if (JumlahA < 0) {
            System.out.println("\n A People Killed on Year " + " : " + "Invalid Data");
        }

        JumlahB = personByod - personBaod;

        if (JumlahB > 0) {
            System.out.println("\n B People Killed on Year " + " : " + JumlahB);
        } else if (JumlahB < 0) {
            System.out.println("\n B People Killed on Year " + " : " + "Invalid Data");
        }

        System.out.print("\n Hasil A : ");
        totalA = input.nextInt();

        for (int i = 0; i < totalA; i++) {
            c = a + b;
            a = b;
            b = c;
            System.out.println(a + "");
            // jumlah = a + c;
            // System.out.println("hasil" + jumlah + "");
        }

        System.out.print("\n Hasil B : ");
        totalB = input.nextInt();
        for (int j = 0; j < totalB; j++) {
            f = d + e;
            d = e;
            e = f;
            System.out.println(d + "");
            // jumlah = a + c;
            // System.out.println("hasil" + jumlah + "");
        }
        System.out.print(" Jumlah A : ");
        nA = input.nextInt();
        System.out.print(" Jumlah B : ");
        nB = input.nextInt();

        // System.out.print(" Jumlah fibonacci A : ");
        // nat = input.nextInt();
        // System.out.print(" Jumlah fibonacci B : ");
        // nbt = input.nextInt();

        rerata = nA + nB;
        Z = rerata / 2;
        System.out.println("\n Rata-rata Nilai " + " : " + Z);
        System.out.println(" ");

        input.close();
    }
}